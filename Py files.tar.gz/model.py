import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader
import matplotlib.pyplot as plt

#from torchtext.legacy import data

import re

from nltk.tokenize import word_tokenize

from tqdm.notebook import tqdm

import string

from hyperparameters import *

class Model(nn.Module):

    def __init__(self, vocab_size, embedding_dim, hidden_dim, batch_first=True, padding_idx=0, dropout=0.2):
        super(Model, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=padding_idx)
        self.rnn = nn.GRU(embedding_dim, hidden_dim, batch_first=batch_first)
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_dim, vocab_size)
        self.hidden_dim = hidden_dim


    def forward(self, x, hidden):
        embedded = self.embedding(x)
        output, hidden = self.rnn(embedded, hidden)
        batch_size_, seq_size, feat_size = output.shape
        output = output.contiguous().view(batch_size_ * seq_size, feat_size)
        output = self.dropout(output)
        output = self.fc(output)

        new_feat_size = output.shape[-1]
        output = output.view(batch_size_, seq_size, new_feat_size)
        return output, hidden

    def init_hidden(self):
        return (torch.zeros(1, batch_size, self.hidden_dim), torch.zeros(1, batch_size, self.hidden_dim))
