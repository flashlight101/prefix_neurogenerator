import torch
import sys
from model import *

index2word = [PAD, EOS] + list(string.ascii_uppercase) + list(string.ascii_lowercase) + necessary_syms

word2index = {token: idx for idx, token in enumerate(index2word)}



def load_pretrained_model(model_path,_device):
    model_s = Model(vocab_size, embedding_dim, hidden_dim)
    model_s.load_state_dict(torch.load(model_path), map_location = torch.device(_device))
    model_s = model_s.to(_device)
    return model_s

def generate(start_chars: str, mdl, temperature=0) -> str:
    mdl.eval()

    st_idx = list(start_chars)
    st_idx = [word2index[w] for w in st_idx]
    res = st_idx.copy()
    hidden, c0 =  mdl.init_hidden()

    hidden = hidden[:, :1, :]
    hidden = hidden.to(device)
    for i, ch in enumerate(st_idx):
        cc = torch.from_numpy(np.array([[ch]], dtype='int'))
        cc = cc.to(device)
        with torch.set_grad_enabled(False):
            out, hidden = mdl(cc, hidden)
            hidden.to(device)
    
    predict = np.argsort(F.softmax(out[0, 0], dim=0).cpu().numpy())[-1 - temperature]
    res = res + [predict]
    if predict == word2index[EOS]:
        res = [index2word[ind] for ind in res]
        res = ''.join([str(elem) for elem in res[:-1]])
        return res
    
    predict = torch.from_numpy(np.array([[predict]], dtype='int'))
    predict = predict.to(device)

    pr_len = seq_length - len(st_idx) - 1

    for p in range(pr_len):
        with torch.set_grad_enabled(False):
            predict, hidden = mdl(predict, hidden)
        predict = np.argmax(F.softmax(predict[0, 0], dim=0).cpu().numpy())
        res = res + [predict]
        if predict == word2index[EOS]:
            break
        predict = torch.from_numpy(np.array([[predict]], dtype='int'))
        predict = predict.to(device)
        hidden.to(device)
    res = [index2word[ind] for ind in res]
    res = ''.join([str(elem) for elem in res[:-1]])
    return res

if __name__ == "__main__":
    model_path = sys.argv[1]
    device = sys.argv[2]
    model = load_pretrained_model(model_path,device)
    model.eval()

    prefix = input("Enter prefix:")
    for i in range(10):
        print(generate(prefix, model, i))

