TOP_N = 1000 # num of classes by first letter

PAD, EOS = '<PAD>', '<EOS>'
necessary_syms = ['ö', 'í', 'ø', 'ó', 'ñ', 'ı']

seq_length = 26

batch_size = 128
epochs = 500
learning_rate = 0.001

embedding_dim = 64
hidden_dim = 64

vocab_size = 60 # latin letters + PAD, EOS and some necessary symbols
